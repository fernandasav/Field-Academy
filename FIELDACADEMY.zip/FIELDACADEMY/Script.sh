#!/bin/bash
echo ________________________________________________________________________
echo --------------------------FIELD ACADEMY--------------------------------
echo
echo Bem-vindo ao terminal da Field Academy!
echo Para começar vamos criar uma pasta para você guardar todo seu conhecimento
echo
echo ________________________________________________________________________
  read -p "Digite qualquer tecla para começar!" REPLY 
   if [ -n  "$REPLY" ]; then  
    echo  "Mostrar pastas!"
   else
    echo "Se precisar sair pressione Crtl + D"
   fi
echo ________________________________________________________________________
echo 
ls
echo "Criar pasta FIELDACADEMY:"
if [ -d "FIELDACADEMY" ]; then
  echo 'Prontinho, já encontramos a pasta na sua área de trabalho!'
elif [ mkdir FIELDACADEMY]; then
  echo "Pasta criada!"
else
  echo "Tente novamente"
fi
echo
echo ________________________________________________________________________
echo
echo Verificamos aqui e você já tem o Node instalado!!!
echo Na versão:
node -v 
echo
echo ________________________________________________________________________
echo
echo Agora vamos criar um arquivo js!
read -p "Preparado?? (Digite qualquer tecla para começar!)" REPLY 
   if [ -n  "$REPLY" ]; then  
    echo  "Criando em 3, 2, 1..."
   else
    echo "Se precisar sair pressione Crtl + D"
   fi
echo .
echo .
echo .
cd FIELDACADEMY
if [ -f "helloWorld.js" ]; then
  echo 'Prontinho, já encontramos seu arquivo na pasta FIELDACADEMY!'
elif [ cat > helloWorld.js ]; then
  echo "Arquivo js criado com sucesso!"
else
  echo "Tente novamente"
fi
echo
echo ________________________________________________________________________
echo
echo Temos uma surpresa para você!

echo olhe essa mensagem no arquivo helloWorld.js

node FIELDACADEMY/helloWord.js

echo Estamos chegando nas nossas funções finais!
read -p "Se deseja continuar aperte qualquer tecla!" REPLY
   if [ -n  "$REPLY" ]; then  
    echo  "Eba! Vamos lá!"
   else
    echo "Se precisar sair pressione Crtl + D"
   fi

echo Estamos agora movendo o arquivo js da pasta FIELD ACADEMY
mv helloWorld.js/teste

echo Compactando a pasta FIELD ACADEMY..em 3,2,1
zip -r FIELDACADEMY.zip

echo Pasta descompactada e excluimos a original para não ter confusão.
del <FIELDACADEMY>
unzip FIELDACADEMY.zip

echo Avalie nosso serviço de 1 a 5 

read -p "Aperte um número de 1 a 5!" REPLY
   if [ -n  "$REPLY" ]; then  
    echo  "Agradecemos por usar nosso programa!"
   else
    echo "Aperte ctrl + D para sair"
fi
